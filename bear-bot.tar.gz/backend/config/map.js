export const config = {
  amapKey: "66a18ffa2c2699b505f23721db07b690", // 使用环境变量或默认值
};
